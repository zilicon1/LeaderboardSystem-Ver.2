﻿using Microsoft.AspNetCore.Mvc;

namespace LeaderboardSystem.Models
{
    public class Mission
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int Points { get; set; }
        public bool IsCompleted { get; set; }

        public ICollection<UserMission> UserMissions { get; set; } = new List<UserMission>();
    }
}
