﻿using Microsoft.AspNetCore.Mvc;

namespace LeaderboardSystem.Models
{
    public class Reward
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int KCCost { get; set; } // Cost in KCCoins to redeem the reward

        public ICollection<UserReward> UserRewards { get; set; } = new List<UserReward>();
    }
}
