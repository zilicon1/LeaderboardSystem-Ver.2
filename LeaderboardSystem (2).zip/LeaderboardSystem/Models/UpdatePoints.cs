﻿using Microsoft.AspNetCore.Mvc;

namespace LeaderboardSystem.Models
{
    public class UpdatePointsRequest
    {
        public int UserId { get; set; }
        public int Points { get; set; }
    }
}
