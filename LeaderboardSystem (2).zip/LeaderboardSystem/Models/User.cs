﻿using Microsoft.AspNetCore.Mvc;

namespace LeaderboardSystem.Models
{
    public class User
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int Points { get; set; }
        public int KCCoins { get; set; }
        public DateTime LastResetDate { get; set; }

        public ICollection<UserMission> UserMissions { get; set; } = new List<UserMission>();
        public ICollection<UserReward> UserRewards { get; set; } = new List<UserReward>();
    }

}

