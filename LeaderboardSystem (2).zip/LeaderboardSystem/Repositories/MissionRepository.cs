﻿using LeaderboardSystem.Data;
using LeaderboardSystem.Models;
using Microsoft.EntityFrameworkCore;

namespace LeaderboardSystem.Repositories
{
    public class MissionRepository : IMissionRepository
    {
        private readonly LeaderboardContext _context;

        public MissionRepository(LeaderboardContext context)
        {
            _context = context;
        }

        public async Task<Mission> GetByIdAsync(int id) => await _context.Missions.FindAsync(id);

        public async Task UpdateAsync(Mission mission)
        {
            _context.Missions.Update(mission);
            await _context.SaveChangesAsync();
        }

        public async Task<List<Mission>> GetAllAsync() => await _context.Missions.ToListAsync();
    }
}

