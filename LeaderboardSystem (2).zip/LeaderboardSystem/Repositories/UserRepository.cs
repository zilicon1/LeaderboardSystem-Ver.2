﻿using LeaderboardSystem.Data;
using LeaderboardSystem.Models;
using Microsoft.EntityFrameworkCore;

namespace LeaderboardSystem.Repositories
{
    public class UserRepository : IUserRepository
    {
        private readonly LeaderboardContext _context;

        public UserRepository(LeaderboardContext context)
        {
            _context = context;
        }

        public async Task<List<User>> GetAllAsync()
        {
            return await _context.Users.ToListAsync();
        }
        public async Task<User> GetByIdAsync(int id) => await _context.Users.FindAsync(id);

        public async Task AddAsync(User user)
        {
            await _context.Users.AddAsync(user);
            await _context.SaveChangesAsync();
        }

        public async Task UpdateAsync(User user)
        {
            _context.Users.Update(user);
            await _context.SaveChangesAsync();
        }

        public async Task AddMissionPointsAsync(User user, Mission mission)
        {
            user.Points += mission.Points;
            await _context.SaveChangesAsync();
        }
    }
}
