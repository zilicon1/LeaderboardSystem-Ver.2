﻿using LeaderboardSystem.Models;

namespace LeaderboardSystem.Services
{
    public interface ILeaderboardService
    {
        Task<List<User>> GetLeaderboardAsync();
        Task AssignSpecialCoinsToTop3Async();
        Task ResetLeaderboardAsync();
        Task UpdatePointsAsync(int userId, int points);
    }
}
    