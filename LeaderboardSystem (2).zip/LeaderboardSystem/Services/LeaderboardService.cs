﻿using LeaderboardSystem.Models;
using LeaderboardSystem.Repositories;
using System;

namespace LeaderboardSystem.Services
{
    public class LeaderboardService : ILeaderboardService
    {
        private readonly IUserRepository _userRepository;

        public LeaderboardService(IUserRepository userRepository)
        {
            _userRepository = userRepository ?? throw new ArgumentNullException(nameof(userRepository));
        }

        // Get the leaderboard (sorted by points in descending order)
        public async Task<List<User>> GetLeaderboardAsync()
        {
            var users = await _userRepository.GetAllAsync();
            return users.OrderByDescending(u => u.Points).ToList();
        }

        // Update user points, ensuring points are non-negative and user exists
        public async Task UpdatePointsAsync(int userId, int points)
        {
            if (points < 0)
            {
                throw new InvalidOperationException("Points cannot be negative.");
            }

            var user = await _userRepository.GetByIdAsync(userId);
            if (user == null)
            {
                throw new InvalidOperationException($"User with ID {userId} not found.");
            }

            user.Points += points;
            await _userRepository.UpdateAsync(user);
        }

        // Assign special KC Coins to the top 3 users based on their points
        public async Task AssignSpecialCoinsToTop3Async()
        {
            var topUsers = (await _userRepository.GetAllAsync())
                .OrderByDescending(u => u.Points)
                .Take(3)
                .ToList();

            for (int i = 0; i < topUsers.Count; i++)
            {
                // Assign different amounts of KC Coins based on ranking
                topUsers[i].KCCoins += i switch
                {
                    0 => 150, // First place
                    1 => 100, // Second place
                    _ => 50  // Third place
                };

                await _userRepository.UpdateAsync(topUsers[i]);
            }
        }

        // Reset the leaderboard by resetting all users' points to zero
        public async Task ResetLeaderboardAsync()
        {
            var users = await _userRepository.GetAllAsync();
            foreach (var user in users)
            {
                user.Points = 0;
                await _userRepository.UpdateAsync(user);
            }
        }

        // Get the next reset date (1st day of the next month at 00:00 Bangkok time)
        public DateTime GetNextResetDate()
        {
            // Get current time in UTC and convert to Bangkok time
            DateTime nowUtc = DateTime.UtcNow;
            TimeZoneInfo bangkokTimeZone = TimeZoneInfo.FindSystemTimeZoneById("Asia/Bangkok");
            DateTime nowBangkok = TimeZoneInfo.ConvertTimeFromUtc(nowUtc, bangkokTimeZone);

            // Set the next reset time to 00:00 on the 1st day of the next month
            DateTime nextReset = new DateTime(
                nowBangkok.Year,
                nowBangkok.Month,
                1,          // Day = 1
                0,          // Hour = 00
                0,          // Minute = 00
                0           // Second = 00
            ).AddMonths(1);   // Add 1 month to get the 1st day of the next month

            return nextReset;
        }
    }
}
